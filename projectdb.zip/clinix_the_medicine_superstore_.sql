-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 29, 2021 at 05:29 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `clinix(the medicine superstore)`
--

-- --------------------------------------------------------

--
-- Table structure for table `bill`
--

CREATE TABLE `bill` (
  `b_id` varchar(20) NOT NULL,
  `p_id` varchar(20) NOT NULL,
  `Drug_id` varchar(20) NOT NULL,
  `Doc_id` varchar(20) NOT NULL,
  `quantity` int(20) NOT NULL,
  `Discount` varchar(20) NOT NULL,
  `Total bill` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bill`
--

INSERT INTO `bill` (`b_id`, `p_id`, `Drug_id`, `Doc_id`, `quantity`, `Discount`, `Total bill`) VALUES
('0001_xx', 'Ali_xx01', 'Paracetamol_00x', 'Dr.m03', 3, '5', 500),
('12345_xx', 'Eesha_44x', 'seacall_x', 'Dr.Atif_z', 2, '5', 1000),
('1234_x', 'Muhammad_01x', 'alcohal_02', 'Dr.m03', 2, '0', 2000),
('1234_xxx', 'Fatima_00xx', 'Panadol_xx', 'Dr.p_02', 5, '0', 100);

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE `doctor` (
  `Doctor Name` varchar(20) NOT NULL,
  `Doctor ID` varchar(20) NOT NULL,
  `Hospital Name` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `doctor`
--

INSERT INTO `doctor` (`Doctor Name`, `Doctor ID`, `Hospital Name`) VALUES
('xyz_00', 'Meu hospital', 'Dr Afan'),
('xyz_000', 'Hameed lateef', 'Dr Usman'),
('1234_v', 'Jinnah hospital', 'Dr Salman'),
('1234_z', 'Children hospital', 'Dr fariha');

-- --------------------------------------------------------

--
-- Table structure for table `drug`
--

CREATE TABLE `drug` (
  `DrugID` varchar(20) NOT NULL,
  `Price` varchar(20) NOT NULL,
  `Quantity` varchar(20) NOT NULL,
  `Exp_Date` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `drug_supplier`
--

CREATE TABLE `drug_supplier` (
  `s_id` varchar(20) NOT NULL,
  `s_name` varchar(20) NOT NULL,
  `contactno` int(20) NOT NULL,
  `cost` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `drug_supplier`
--

INSERT INTO `drug_supplier` (`s_id`, `s_name`, `contactno`, `cost`) VALUES
('3456', 'Shan', 2050, 2147483647),
('34567', 'Brothers', 5000, 34324456);

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE `patient` (
  `p_id` varchar(20) NOT NULL,
  `address` varchar(20) NOT NULL,
  `p_name` varchar(20) NOT NULL,
  `p_details` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `pharmacy`
--

CREATE TABLE `pharmacy` (
  `ph_id` varchar(20) NOT NULL,
  `ph_name` varchar(20) NOT NULL,
  `city` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `pharmacy`
--

INSERT INTO `pharmacy` (`ph_id`, `ph_name`, `city`) VALUES
('clinix', '12345_xx', 'Islamabad'),
('drugs 24/7', '12345_x', 'Istambol');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `bill`
--
ALTER TABLE `bill`
  ADD PRIMARY KEY (`b_id`);

--
-- Indexes for table `drug`
--
ALTER TABLE `drug`
  ADD PRIMARY KEY (`DrugID`);

--
-- Indexes for table `drug_supplier`
--
ALTER TABLE `drug_supplier`
  ADD PRIMARY KEY (`s_id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`p_id`);

--
-- Indexes for table `pharmacy`
--
ALTER TABLE `pharmacy`
  ADD PRIMARY KEY (`ph_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
