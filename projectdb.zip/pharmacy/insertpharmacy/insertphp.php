<?php
$a= $_POST['a'];
$b= $_POST['b'];
$c= $_POST['c'];




$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Clinix(The Medicine Superstore)";

// Create connection
$conn = new mysqli($servername, $username,'',$dbname);

if ($conn->connect_error)	
{
    die("Connection failed: " . $conn->connect_error);
}
{ 
echo "Connected successfully";
}

$q="INSERT INTO pharmacy VALUES('$a','$b','$c')";
if ($conn->query($q) === TRUE)
{
    echo "New record created successfully";
} else {
    echo "Error: " . $q . "<br>" . $conn->error;
}

?>