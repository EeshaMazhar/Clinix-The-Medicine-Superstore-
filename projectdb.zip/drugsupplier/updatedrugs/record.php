<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Clinix(The Medicine Superstore)";

$conn = new mysqli($servername, $username,'',$dbname);


if ($conn->connect_error) {
	
    die("Connection failed: " . $conn->connect_error);
}
else
{ 
//echo "Connected Database successfully";
}

?>
<!doctype html>
<html>
<head>

</head>
<body>

<h1 align="center">Car RECORD Update</h1>

<table border="1" align="center" style="line-height:25px;">
<tr>
<th>s_id</th>
<th>s_name</th>
<th>cost</th>
<th>contactno</th>

</tr>
<?php
$sql = "SELECT * FROM drug_supplier";
$result = $conn->query($sql);
if($result->num_rows > 0){
 while($row = $result->fetch_assoc()){
 ?>
 <tr>

<td> <?php  echo $row['s_id'];?></td>
<td> <?php  echo $row['s_name'];?></td>
<td> <?php  echo $row['cost'];?></td>
<td> <?php  echo $row['contactno'];?></td>

 <td><a href="edit.php?edit_id=<?php echo $row['s_id']; ?>" alt="edit" >Edit/update</a></td>
 </tr>
 <?php
 }
 }
 else
 {
 ?>
 <tr>
 <th colspan="2">There's No data found!!!</th>
 </tr>
 <?php
}
?>
</table>
</body>
</html>